import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import jsPDF from 'jspdf';
import type { LayoutSettings } from '../types';
import { defaultLayoutSettings, fontOptions } from '../constants';

const CopyIcon: React.FC<{className?: string}> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
  </svg>
);

const DocumentDownloadIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
    </svg>
);

const PrintIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H7a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm-8-14h12a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v2a2 2 0 002 2z" />
    </svg>
);

const TagIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.568 3H5.25A2.25 2.25 0 003 5.25v4.318c0 .597.237 1.17.659 1.591l9.581 9.581c.699.699 1.78.872 2.607.33a18.095 18.095 0 005.223-5.223c.542-.827.369-1.908-.33-2.607L11.16 3.66A2.25 2.25 0 009.568 3z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 6h.008v.008H6V6z" />
    </svg>
);

const ResetIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0011.664 0l3.181-3.183m-4.991-2.691L7.5 7.5l-2.682 2.682A8.25 8.25 0 009.75 21.75l3.182-3.182m0-4.242l-3.182-3.182" />
    </svg>
);

const SaveIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" />
    </svg>
);

const SparkleIcon: React.FC<{className?: string}> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456zM16.898 20.562L16.25 21.75l-.648-1.188a2.25 2.25 0 01-1.47-1.47L12.964 18l1.188-.648a2.25 2.25 0 011.47-1.47L16.25 15l.648 1.188a2.25 2.25 0 011.47 1.47L19.536 18l-1.188.648a2.25 2.25 0 01-1.47 1.47z" />
  </svg>
);

const PhotoIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
    </svg>
);

const AdjustmentsHorizontalIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 6h9.75M10.5 6a1.5 1.5 0 11-3 0m3 0a1.5 1.5 0 10-3 0M3.75 6H7.5m3 12h9.75m-9.75 0a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m-3.75 0H7.5m9-6h3.75m-3.75 0a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m-9.75 0h9.75" />
    </svg>
);
const ChevronDownIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
    </svg>
);


interface GeneratedNoteProps {
  noteText: string;
  isGenerating: boolean;
  error: string | null;
  isFormEmpty: boolean;
  onGenerate: () => void;
  onReset: () => void;
  settings: LayoutSettings;
  setSettings: React.Dispatch<React.SetStateAction<LayoutSettings>>;
  onSave: (name: string) => void;
}

const GeneratedNote: React.FC<GeneratedNoteProps> = ({ 
    noteText, 
    isGenerating, 
    error, 
    isFormEmpty, 
    onGenerate, 
    onReset,
    settings,
    setSettings,
    onSave,
}) => {
  const [isCopied, setIsCopied] = useState(false);
  const [showSettings, setShowSettings] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const previewRef = useRef<HTMLDivElement>(null);
  const dragStartRef = useRef<{ startX: number, startY: number, initialLeft: number, initialTop: number } | null>(null);
  
  // Page dimensions in cm for calculations
  const PAGE_WIDTH_CM = 21.59;
  const PAGE_HEIGHT_CM = 27.94;
  const PT_TO_CM = 0.0352778;

  const [backgroundImage, setBackgroundImage] = useState<string>(() => localStorage.getItem('customFormBackgroundImage') || '');

  const browserFontStack = useMemo(() => {
    switch(settings.fontFamily) {
        case 'courier': return "'Courier New', Courier, monospace";
        case 'helvetica': return "Helvetica, Arial, sans-serif";
        case 'times': return "'Times New Roman', Times, serif";
        default: return "'Courier New', Courier, monospace";
    }
  }, [settings.fontFamily]);

  const noteLines = useMemo(() => {
      if (!noteText) return [];

      const doc = new jsPDF({
          orientation: 'p',
          unit: 'cm',
          format: [PAGE_WIDTH_CM, PAGE_HEIGHT_CM]
      });
      
      const fontStyle = settings.fontWeight >= 600 ? 'bold' : 'normal';
      doc.setFont(settings.fontFamily, fontStyle);
      doc.setFontSize(settings.fontSize);

      // NOTE: splitTextToSize does not account for letter spacing.
      // The user can adjust textBlockWidth manually to compensate.
      return doc.splitTextToSize(noteText, settings.textBlockWidth);
  }, [noteText, settings.fontSize, settings.textBlockWidth, settings.fontFamily, settings.fontWeight]);

  useEffect(() => {
    if (isCopied) {
      const timer = setTimeout(() => setIsCopied(false), 2000);
      return () => clearTimeout(timer);
    }
  }, [isCopied]);

  const handleCopy = () => {
    if (noteText) {
      navigator.clipboard.writeText(noteText);
      setIsCopied(true);
    }
  };

  const generatePdf = (format: 'letter' | 'a4') => {
    const isA4 = format === 'a4';
    const doc = new jsPDF({
      orientation: 'p',
      unit: 'cm',
      format: isA4 ? 'a4' : [PAGE_WIDTH_CM, PAGE_HEIGHT_CM]
    });

    const pageWidth = isA4 ? 21.0 : PAGE_WIDTH_CM;
    const pageHeight = isA4 ? 29.7 : PAGE_HEIGHT_CM;

    if (backgroundImage) {
        doc.addImage(backgroundImage, 'PNG', 0, 0, pageWidth, pageHeight);
    }

    const fontStyle = settings.fontWeight >= 600 ? 'bold' : 'normal';
    doc.setFont(settings.fontFamily, fontStyle);
    doc.setFontSize(settings.fontSize);

    const splitText = doc.splitTextToSize(noteText, settings.textBlockWidth);
    
    const grayValue = Math.floor(255 * (1 - settings.textOpacity));
    doc.setTextColor(grayValue);

    doc.text(splitText, settings.textLeftPosition, settings.textTopPosition, { 
        lineHeightFactor: settings.lineHeight, 
        baseline: 'top',
        charSpace: settings.letterSpacing * PT_TO_CM,
    });

    doc.save(`note-infirmiere_${isA4 ? 'A4' : 'Lettre'}.pdf`);
  };
  
  const generateLabelPdf = () => {
    const labelWidth = 10; // cm
    const labelHeight = 15; // cm
    const doc = new jsPDF({
        orientation: 'p',
        unit: 'cm',
        format: [labelWidth, labelHeight]
    });
    
    const fontStyle = settings.fontWeight >= 600 ? 'bold' : 'normal';

    doc.setTextColor(0); // Black for header
    doc.setFont(settings.fontFamily, 'bold');
    doc.setFontSize(12);
    doc.text('Note d\'Évolution', 1, 1.5);
    
    doc.setLineWidth(0.02);
    doc.line(1, 2.5, labelWidth - 1, 2.5);
    
    const grayValue = Math.floor(255 * (1 - settings.textOpacity));
    doc.setTextColor(grayValue);
    doc.setFont(settings.fontFamily, fontStyle);
    doc.setFontSize(9);
    const textMargin = 1;
    const textBlockWidth = labelWidth - (textMargin * 2);
    const splitText = doc.splitTextToSize(noteText, textBlockWidth);
    
    doc.text(splitText, textMargin, 3.2);

    doc.save('note-etiquette.pdf');
  };
  
  const handlePrint = () => {
    if (!noteText) return;

    const iframe = document.createElement('iframe');
    iframe.style.position = 'absolute';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = 'none';
    iframe.setAttribute('title', 'Print Frame'); // For accessibility

    document.body.appendChild(iframe);

    const printDoc = iframe.contentWindow?.document;
    if (!printDoc) {
      console.error("Could not access iframe document for printing.");
      document.body.removeChild(iframe);
      return;
    }

    const safeNoteText = noteText.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

    printDoc.open();
    printDoc.write(`
      <html>
        <head>
          <title>Impression - Note d'Évolution</title>
          <style>
            @page {
              size: letter;
              margin: 0;
            }
            body {
              margin: 0;
              font-family: ${browserFontStack};
              width: ${PAGE_WIDTH_CM}cm;
              height: ${PAGE_HEIGHT_CM}cm;
            }
            .page-container {
              position: relative;
              width: 100%;
              height: 100%;
              overflow: hidden;
            }
            .background-image {
              position: absolute;
              top: 0;
              left: 0;
              width: 100%;
              height: 100%;
              object-fit: contain;
            }
            .text-content {
              position: absolute;
              box-sizing: border-box;
              padding: 0;
              margin: 0;
              top: ${settings.textTopPosition}cm;
              left: ${settings.textLeftPosition}cm;
              width: ${settings.textBlockWidth}cm;
              color: rgba(0, 0, 0, ${settings.textOpacity});
              font-weight: ${settings.fontWeight};
              font-size: ${settings.fontSize}pt;
              line-height: ${settings.lineHeight};
              letter-spacing: ${settings.letterSpacing}pt;
              white-space: pre-wrap;
              word-wrap: break-word;
            }
          </style>
        </head>
        <body>
          <div class="page-container">
            ${backgroundImage ? `<img src="${backgroundImage}" class="background-image" />` : ''}
            <div class="text-content">${safeNoteText}</div>
          </div>
        </body>
      </html>
    `);
    printDoc.close();
    
    iframe.onload = () => {
      setTimeout(() => {
        iframe.contentWindow?.focus();
        iframe.contentWindow?.print();
        setTimeout(() => {
            if (iframe.parentNode) {
                iframe.parentNode.removeChild(iframe);
            }
        }, 500);
      }, 250);
    };
  };


  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => {
            const result = e.target?.result as string;
            setBackgroundImage(result);
            localStorage.setItem('customFormBackgroundImage', result);
        };
        reader.readAsDataURL(file);
    }
  };

  const triggerFileUpload = () => {
    fileInputRef.current?.click();
  };

  const resetBackgroundImage = () => {
    setBackgroundImage('');
    localStorage.removeItem('customFormBackgroundImage');
  };

  const handleResetSettings = () => {
    setSettings(defaultLayoutSettings);
  };
  
  const handleSettingChange = (field: keyof LayoutSettings, value: number | string) => {
    setSettings(prev => ({ ...prev, [field]: value }));
  };

  const handleMouseDown = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (!noteText || isGenerating) return;
    e.preventDefault();
    dragStartRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      initialLeft: settings.textLeftPosition,
      initialTop: settings.textTopPosition,
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  }, [settings, noteText, isGenerating]);
  
  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!dragStartRef.current || !previewRef.current) return;

    const { startX, startY, initialLeft, initialTop } = dragStartRef.current;
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;

    const { width: previewWidth, height: previewHeight } = previewRef.current.getBoundingClientRect();

    const dLeftCm = (dx / previewWidth) * PAGE_WIDTH_CM;
    const dTopCm = (dy / previewHeight) * PAGE_HEIGHT_CM;

    const newLeft = Math.max(0.5, Math.min(20, initialLeft + dLeftCm));
    const newTop = Math.max(0.5, Math.min(27, initialTop + dTopCm));
    
    setSettings(prev => ({
        ...prev,
        textLeftPosition: newLeft,
        textTopPosition: newTop,
    }));
  }, [setSettings]);

  const handleMouseUp = useCallback(() => {
    dragStartRef.current = null;
    document.removeEventListener('mousemove', handleMouseMove);
    document.removeEventListener('mouseup', handleMouseUp);
  }, [handleMouseMove]);

  const handleSaveNote = () => {
      const name = prompt("Entrez un nom pour sauvegarder la note et sa mise en page :");
      if (name && name.trim()) {
          onSave(name.trim());
      }
  };

  const adjustmentsPanel = (
    <div className="space-y-4">
        <div className="hidden lg:flex items-center justify-between gap-2 font-medium text-slate-700 dark:text-slate-300">
            <div className="flex items-center gap-2">
                 <AdjustmentsHorizontalIcon className="w-6 h-6" />
                 <h3 className="text-lg font-bold">Ajustements</h3>
            </div>
            <button onClick={handleResetSettings} className="p-1.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors" title="Réinitialiser les ajustements d'affichage">
                <ResetIcon className="w-4 h-4 text-slate-500" />
            </button>
        </div>
        <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-4 lg:p-0 lg:bg-transparent lg:dark:bg-transparent">
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4 bg-teal-50 dark:bg-teal-900/30 p-2 rounded-md border border-teal-200 dark:border-teal-800">
                <b>Astuce :</b> Vous pouvez aussi cliquer et glisser le texte dans l'aperçu pour le positionner.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-1 gap-x-6 gap-y-4 text-sm">
                
                <div>
                    <label htmlFor="textTopPosition" className="block mb-1 text-slate-600 dark:text-slate-400">Position Verticale (cm): <span className="font-mono text-xs">{settings.textTopPosition.toFixed(2)}</span></label>
                    <input type="range" id="textTopPosition" min="0.5" max="27" step="0.05" value={settings.textTopPosition} onChange={e => handleSettingChange('textTopPosition', parseFloat(e.target.value))} className="w-full" />
                </div>
                <div>
                    <label htmlFor="textLeftPosition" className="block mb-1 text-slate-600 dark:text-slate-400">Position Horizontale (cm): <span className="font-mono text-xs">{settings.textLeftPosition.toFixed(2)}</span></label>
                    <input type="range" id="textLeftPosition" min="0.5" max="20" step="0.05" value={settings.textLeftPosition} onChange={e => handleSettingChange('textLeftPosition', parseFloat(e.target.value))} className="w-full" />
                </div>
                <div>
                    <label htmlFor="textBlockWidth" className="block mb-1 text-slate-600 dark:text-slate-400">Largeur du bloc de texte (cm): <span className="font-mono text-xs">{settings.textBlockWidth.toFixed(2)}</span></label>
                    <input type="range" id="textBlockWidth" min="10" max="20" step="0.05" value={settings.textBlockWidth} onChange={e => handleSettingChange('textBlockWidth', parseFloat(e.target.value))} className="w-full" />
                </div>

                <hr className="md:col-span-2 lg:col-span-1 border-slate-200 dark:border-slate-700 my-2" />
                
                <div>
                    <label htmlFor="fontFamily" className="block mb-1 text-slate-600 dark:text-slate-400">Police de caractères</label>
                    <select
                        id="fontFamily"
                        value={settings.fontFamily}
                        onChange={(e) => handleSettingChange('fontFamily', e.target.value)}
                        className="w-full p-2 border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 rounded-md focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors"
                    >
                        {fontOptions.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                    </select>
                </div>
                <div>
                    <label htmlFor="fontSize" className="block mb-1 text-slate-600 dark:text-slate-400">Taille de police (pt): <span className="font-mono text-xs">{settings.fontSize.toFixed(1)}</span></label>
                    <input type="range" id="fontSize" min="7" max="14" step="0.5" value={settings.fontSize} onChange={e => handleSettingChange('fontSize', parseFloat(e.target.value))} className="w-full" />
                </div>
                <div>
                    <label htmlFor="fontWeight" className="block mb-1 text-slate-600 dark:text-slate-400">Épaisseur du texte: <span className="font-mono text-xs">{settings.fontWeight === 400 ? 'Normal' : 'Gras'}</span></label>
                    <input type="range" id="fontWeight" min="400" max="700" step="300" value={settings.fontWeight} onChange={e => handleSettingChange('fontWeight', parseFloat(e.target.value))} className="w-full" />
                </div>
                 <div>
                    <label htmlFor="lineHeight" className="block mb-1 text-slate-600 dark:text-slate-400">Hauteur de ligne: <span className="font-mono text-xs">{settings.lineHeight.toFixed(2)}</span></label>
                    <input type="range" id="lineHeight" min="1.5" max="2.5" step="0.01" value={settings.lineHeight} onChange={e => handleSettingChange('lineHeight', parseFloat(e.target.value))} className="w-full" />
                </div>
                 <div>
                    <label htmlFor="letterSpacing" className="block mb-1 text-slate-600 dark:text-slate-400">Espacement lettres (pt): <span className="font-mono text-xs">{settings.letterSpacing.toFixed(2)}</span></label>
                    <input type="range" id="letterSpacing" min="-1" max="5" step="0.05" value={settings.letterSpacing} onChange={e => handleSettingChange('letterSpacing', parseFloat(e.target.value))} className="w-full" />
                </div>
                <div>
                    <label htmlFor="textOpacity" className="block mb-1 text-slate-600 dark:text-slate-400">Densité du texte: <span className="font-mono text-xs">{Math.round(settings.textOpacity * 100)}%</span></label>
                    <input type="range" id="textOpacity" min="0.1" max="1" step="0.05" value={settings.textOpacity} onChange={e => handleSettingChange('textOpacity', parseFloat(e.target.value))} className="w-full" />
                </div>

            </div>
            <div className="mt-6 pt-4 border-t border-slate-200 dark:border-slate-600">
                <h4 className="block mb-2 text-slate-600 dark:text-slate-400 font-medium">Image de fond</h4>
                <div className="flex items-center gap-3">
                        <input
                        type="file"
                        ref={fileInputRef}
                        onChange={handleImageUpload}
                        className="hidden"
                        accept="image/png, image/jpeg"
                    />
                    <button onClick={triggerFileUpload} className="inline-flex items-center gap-2 px-3 py-1.5 border border-slate-300 dark:border-slate-600 text-sm font-medium rounded-md shadow-sm text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-700 hover:bg-slate-50 dark:hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500">
                        <PhotoIcon className="w-4 h-4" />
                        Changer l'image...
                    </button>
                    <button onClick={resetBackgroundImage} className="p-1.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors" title="Supprimer l'image de fond">
                        <ResetIcon className="w-4 h-4 text-slate-500" />
                    </button>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
                    Chargez votre propre formulaire. L'image est sauvegardée localement.
                </p>
            </div>
        </div>
    </div>
  );

  const isDraggable = noteText && !isGenerating;

  return (
    <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md p-6 border border-slate-200 dark:border-slate-700 relative">
        <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold text-slate-700 dark:text-slate-300">Aperçu de la Note d'Évolution</h2>
            <div className="flex items-center gap-2">
            <button onClick={onReset} className="p-2 rounded-full hover:bg-slate-100 active:bg-slate-200 dark:hover:bg-slate-700 dark:active:bg-slate-600 transition-colors" title="Réinitialiser le formulaire">
                    <ResetIcon className="w-6 h-6 text-slate-500 dark:text-slate-400" />
                </button>
            <button 
                onClick={onGenerate} 
                disabled={isGenerating || isFormEmpty} 
                className="inline-flex items-center gap-2 px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-teal-600 hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 disabled:bg-slate-400 dark:disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors"
            >
                <SparkleIcon className="w-5 h-5" />
                {isGenerating ? 'Génération...' : 'Générer la Note'}
            </button>
            </div>
        </div>
      
        {error && <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert"><p>{error}</p></div>}
      
        <div className="grid grid-cols-1 lg:grid-cols-5 lg:gap-6">
            <div className="lg:col-span-3">
                <div ref={previewRef} className="relative w-full border border-slate-300 dark:border-slate-600 rounded-md overflow-hidden bg-white aspect-[8.5/11]">
                    {backgroundImage && (
                        <img src={backgroundImage} alt="Formulaire de note d'évolution" className="absolute inset-0 w-full h-full object-contain select-none" style={{ pointerEvents: 'none' }} />
                    )}
                    
                    <div 
                        onMouseDown={handleMouseDown}
                        className={`absolute transition-shadow duration-200
                            ${isDraggable ? 'cursor-move hover:outline-dotted hover:outline-2 hover:outline-slate-400/50' : ''}
                            ${dragStartRef.current ? 'outline-dotted outline-2 outline-teal-500/80 shadow-lg' : ''}
                        `}
                        style={{
                            color: `rgba(0, 0, 0, ${settings.textOpacity})`,
                            fontFamily: browserFontStack,
                            fontWeight: settings.fontWeight,
                            top: `${(settings.textTopPosition / PAGE_HEIGHT_CM) * 100}%`,
                            left: `${(settings.textLeftPosition / PAGE_WIDTH_CM) * 100}%`,
                            width: `${(settings.textBlockWidth / PAGE_WIDTH_CM) * 100}%`,
                        }}
                    >
                       {isGenerating 
                            ? <div style={{fontSize: '1rem', whiteSpace: 'pre-wrap', color: 'rgb(100 116 139)'}}>Génération en cours, veuillez patienter...</div> 
                            : noteLines.map((line, index) => (
                              <div
                                  key={index}
                                  style={{
                                      fontSize: `${settings.fontSize}pt`,
                                      lineHeight: settings.lineHeight,
                                      letterSpacing: `${settings.letterSpacing}pt`,
                                      whiteSpace: 'pre',
                                  }}
                              >
                                  {line || '\u00A0'}
                              </div>
                          ))}
                    </div>
                
                    {!noteText && !isGenerating && (
                        <div className="absolute inset-0 flex items-center justify-center bg-white/70 dark:bg-slate-800/70 backdrop-blur-[2px]">
                            <p className="text-slate-500 dark:text-slate-400 text-center p-4 font-sans text-base bg-slate-100/80 dark:bg-slate-900/80 rounded-lg shadow">
                                {backgroundImage 
                                    ? "La note générée par l'IA apparaîtra ici." 
                                    : "Chargez une image de formulaire via les ajustements, puis remplissez le formulaire pour commencer."
                                }
                            </p>
                        </div>
                    )}
                
                    {isDraggable && (
                    <div className="absolute top-2 right-2 flex gap-1.5">
                        <button onClick={handleSaveNote} className="p-2 rounded-md bg-white/80 backdrop-blur-sm dark:bg-slate-700/80 hover:bg-white dark:hover:bg-slate-600 transition-colors shadow-md" title="Enregistrer la note et la mise en page">
                            <SaveIcon className="w-5 h-5 text-slate-600 dark:text-slate-300" />
                        </button>
                        <button onClick={handleCopy} className="p-2 rounded-md bg-white/80 backdrop-blur-sm dark:bg-slate-700/80 hover:bg-white dark:hover:bg-slate-600 transition-colors shadow-md" title="Copier le texte">
                        <CopyIcon className="w-5 h-5 text-slate-600 dark:text-slate-300" />
                        </button>
                        <button onClick={() => generatePdf('letter')} className="p-2 rounded-md bg-white/80 backdrop-blur-sm dark:bg-slate-700/80 hover:bg-white dark:hover:bg-slate-600 transition-colors shadow-md" title="Télécharger en PDF (Format Lettre US)">
                            <DocumentDownloadIcon className="w-5 h-5 text-slate-600 dark:text-slate-300" />
                        </button>
                        <button onClick={handlePrint} className="p-2 rounded-md bg-white/80 backdrop-blur-sm dark:bg-slate-700/80 hover:bg-white dark:hover:bg-slate-600 transition-colors shadow-md" title="Imprimer directement">
                        <PrintIcon className="w-5 h-5 text-slate-600 dark:text-slate-300" />
                        </button>
                        <button onClick={generateLabelPdf} className="p-2 rounded-md bg-white/80 backdrop-blur-sm dark:bg-slate-700/80 hover:bg-white dark:hover:bg-slate-600 transition-colors shadow-md" title="Imprimer Étiquette">
                        <TagIcon className="w-5 h-5 text-slate-600 dark:text-slate-300" />
                        </button>
                    </div>
                    )}
                </div>
            </div>

            <div className="lg:col-span-2 mt-6 lg:mt-0">
                <button onClick={() => setShowSettings(!showSettings)} className="flex justify-between items-center w-full text-left p-2 rounded-md hover:bg-slate-100 dark:hover:bg-slate-700 lg:hidden">
                    <div className="flex items-center gap-2 font-medium text-slate-600 dark:text-slate-400">
                        <AdjustmentsHorizontalIcon className="w-5 h-5" />
                        <span>Ajuster l'affichage</span>
                    </div>
                    <ChevronDownIcon className={`w-5 h-5 text-slate-500 dark:text-slate-400 transition-transform ${showSettings ? 'rotate-180' : ''}`} />
                </button>
                <div className={`${showSettings ? 'block' : 'hidden'} lg:block`}>
                  {adjustmentsPanel}
                </div>
            </div>
        </div>

       {isCopied && <div className="absolute bottom-5 right-5 bg-slate-800 text-white text-sm py-1 px-3 rounded-md animate-pulse">Copié !</div>}
    </div>
  );
};

export default GeneratedNote;