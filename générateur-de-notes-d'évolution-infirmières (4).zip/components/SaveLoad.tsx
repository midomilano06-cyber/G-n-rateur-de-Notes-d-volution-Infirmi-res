import React, { useState } from 'react';
import CollapsibleSection from './CollapsibleSection';

const SaveIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" />
    </svg>
);

const FolderOpenIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 9.75h6.072c.56.005.918.444 1.059.998L12 12l.67 1.252a1.125 1.125 0 001.06.998h6.072M3.75 9.75L2.25 12l1.5 2.25M20.25 9.75L21.75 12l-1.5 2.25M3.75 15h6.072c.56.005.918-.444 1.059-.998L12 12l.67-1.252a1.125 1.125 0 011.06-.998h6.072" />
    </svg>
);

const TrashIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
    </svg>
);


interface SaveLoadProps {
    savedStates: string[];
    onSave: (name: string) => void;
    onLoad: (name: string) => void;
    onDelete: (name: string) => void;
}

const SaveLoad: React.FC<SaveLoadProps> = ({ savedStates, onSave, onLoad, onDelete }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [saveName, setSaveName] = useState('');
    const [selectedName, setSelectedName] = useState('');

    const handleSave = () => {
        if (saveName.trim()) {
            onSave(saveName);
            setSaveName('');
        } else {
            alert("Veuillez entrer un nom pour la sauvegarde.");
        }
    };

    const handleLoad = () => {
        if (selectedName) {
            onLoad(selectedName);
        } else {
            alert("Veuillez sélectionner une note à charger.");
        }
    };
    
    const handleDelete = () => {
        if (selectedName) {
            onDelete(selectedName);
            setSelectedName('');
        } else {
            alert("Veuillez sélectionner une note à supprimer.");
        }
    };

    React.useEffect(() => {
        if (savedStates.length > 0 && !selectedName) {
            setSelectedName(savedStates[0]);
        }
        if (savedStates.length === 0) {
            setSelectedName('');
        }
    }, [savedStates, selectedName]);
    
    return (
        <CollapsibleSection
            title="Enregistrement / Chargement"
            isOpen={isOpen}
            onToggle={() => setIsOpen(!isOpen)}
            isFilled={savedStates.length > 0}
        >
            <div className="space-y-6">
                <div>
                    <h3 className="text-md font-semibold text-slate-600 dark:text-slate-400 mb-2">Enregistrer la note actuelle</h3>
                    <div className="flex flex-col sm:flex-row gap-2">
                        <input
                            type="text"
                            value={saveName}
                            onChange={(e) => setSaveName(e.target.value)}
                            placeholder="Nom de la sauvegarde..."
                            className="flex-grow p-2 border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 rounded-md focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors"
                        />
                        <button onClick={handleSave} className="inline-flex items-center justify-center gap-2 px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-teal-600 hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500">
                            <SaveIcon className="w-5 h-5" />
                            <span>Enregistrer</span>
                        </button>
                    </div>
                </div>

                <div>
                    <h3 className="text-md font-semibold text-slate-600 dark:text-slate-400 mb-2">Charger une note</h3>
                    {savedStates.length > 0 ? (
                        <div className="flex flex-col sm:flex-row gap-2">
                            <select
                                value={selectedName}
                                onChange={(e) => setSelectedName(e.target.value)}
                                className="flex-grow p-2 border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 rounded-md focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors"
                            >
                                {savedStates.map(name => <option key={name} value={name}>{name}</option>)}
                            </select>
                            <div className="flex gap-2">
                                <button onClick={handleLoad} className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2 border border-slate-300 dark:border-slate-600 text-sm font-medium rounded-md shadow-sm text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-700 hover:bg-slate-50 dark:hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500">
                                    <FolderOpenIcon className="w-5 h-5" />
                                    <span>Charger</span>
                                </button>
                                <button onClick={handleDelete} className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500">
                                    <TrashIcon className="w-5 h-5" />
                                     <span>Supprimer</span>
                                </button>
                            </div>
                        </div>
                    ) : (
                        <p className="text-sm text-slate-500 dark:text-slate-400">Aucune note enregistrée.</p>
                    )}
                </div>
            </div>
        </CollapsibleSection>
    );
};

export default SaveLoad;
