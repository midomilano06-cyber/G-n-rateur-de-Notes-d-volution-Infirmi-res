import React from 'react';
import { scenariosData } from '../constants';
import type { FormState } from '../types';

const BoltIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 13.5l10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75z" />
    </svg>
);


interface QuickScenariosProps {
  onScenarioSelect: (scenarioState: Partial<FormState>) => void;
}

const QuickScenarios: React.FC<QuickScenariosProps> = ({ onScenarioSelect }) => {
  return (
    <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md p-6 border border-slate-200 dark:border-slate-700">
      <h2 className="text-xl font-bold text-slate-700 dark:text-slate-300 mb-4 flex items-center gap-2">
        <BoltIcon className="w-6 h-6 text-teal-500" />
        Scénarios Rapides
      </h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {scenariosData.map(scenario => (
          <button
            key={scenario.label}
            onClick={() => onScenarioSelect(scenario.state)}
            className="px-4 py-2 border border-slate-300 dark:border-slate-600 text-sm font-medium rounded-md shadow-sm text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-700 hover:bg-slate-50 dark:hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-slate-800 focus:ring-teal-500 transition-colors"
          >
            {scenario.label}
          </button>
        ))}
      </div>
      <p className="text-xs text-slate-500 dark:text-slate-400 mt-3">Cliquez sur un scénario pour pré-remplir le formulaire avec des données courantes.</p>
    </div>
  );
};

export default QuickScenarios;
